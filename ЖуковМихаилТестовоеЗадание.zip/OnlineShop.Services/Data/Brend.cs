﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShop.Services.Data
{
    public class Brend
    {
        public int Id { get; set; }
        public String BrendName { get; set; }
    }
}
