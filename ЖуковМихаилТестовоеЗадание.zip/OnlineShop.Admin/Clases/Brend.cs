﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace OnlineShop.Admin.Clases
{
    public class Brend
    {
        public int Id { get; set; }
        public String BrendName { get; set; }
    }
}
